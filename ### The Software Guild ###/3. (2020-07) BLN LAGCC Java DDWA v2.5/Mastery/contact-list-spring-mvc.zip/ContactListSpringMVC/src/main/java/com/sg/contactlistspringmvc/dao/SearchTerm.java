package com.sg.contactlistspringmvc.dao;

/**
 *
 * @author ward
 */
public enum SearchTerm {
    FIRST_NAME, LAST_NAME, COMPANY, PHONE, EMAIL
}
