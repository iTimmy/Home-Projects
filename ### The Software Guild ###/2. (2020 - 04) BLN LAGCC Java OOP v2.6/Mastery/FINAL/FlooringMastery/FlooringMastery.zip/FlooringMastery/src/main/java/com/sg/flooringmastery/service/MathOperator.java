package com.sg.flooringmastery.service;

public enum MathOperator {
    PLUS, MINUS, MULTIPLY, DIVIDE

}