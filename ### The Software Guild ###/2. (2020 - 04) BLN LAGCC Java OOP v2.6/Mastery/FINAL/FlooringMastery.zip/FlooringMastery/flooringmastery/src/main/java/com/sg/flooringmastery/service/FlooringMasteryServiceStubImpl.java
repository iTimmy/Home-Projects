/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooringmastery.service;

import com.sg.flooringmastery.dto.Order;
import com.sg.flooringmastery.dto.Product;
import com.sg.flooringmastery.dto.Tax;
import com.sg.flooringmastery.dao.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author Music Account
 */
@Component
public class FlooringMasteryServiceStubImpl implements FlooringMasteryService {
    private FlooringMasteryOrderDao onlyOrder;
    private FlooringMasteryProductDao onlyProduct;
    private FlooringMasteryTaxDao onlyTax;
    
    @Autowired
    public FlooringMasteryServiceStubImpl() {

    }
    
    public FlooringMasteryServiceStubImpl(FlooringMasteryOrderDao onlyOrder, FlooringMasteryProductDao onlyProduct, FlooringMasteryTaxDao onlyTax){
         this.onlyOrder = onlyOrder;
         this.onlyProduct = onlyProduct;
         this.onlyTax = onlyTax;
     }
    
    @Override
    public Order createOrder(Order order) throws Exception {
        Order orderDao = onlyOrder.createOrder(order);
        return orderDao;
    }
    
    @Override
    public List<Order> getActiveOrders() throws Exception {
        List<Order> listActiveOrders = new ArrayList<>();
        return listActiveOrders;
    }
    
   @Override
    public List<Order> getOrdersByDate(LocalDate userInputDate) throws Exception {
        List<Order> listOrders = onlyOrder.getOrdersByDate(userInputDate);
        if (listOrders == null) {
            return null;
        } else {
            return listOrders;
        }
    }

    @Override
    public Order getOrderByID(int orderNumber) {
        Order order = onlyOrder.getOrderByID(orderNumber);
        return order;
    }

    @Override
    public void updateOrder(Order editedOrder, Order existingOrder) {
        try {
            onlyOrder.updateOrder(editedOrder, existingOrder);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteOrder(Order orderNumber) throws Exception {
        onlyOrder.deleteOrder(orderNumber);
    }   

    @Override
    public boolean saveOrdersByDate() throws Exception {
        if (onlyOrder.saveOrdersByDate() == false) {
            return false;
        } else {
            return true;
        }
    }



    // PRODUCTS \\
    @Override
    public List<Product> getAllProducts() {
        List<Product> listProducts = onlyProduct.getAllProducts();
        return listProducts;
    }

    @Override
    public Product getProductByName(String productName) {
        return onlyProduct.getProductByName(productName);
    }



    // TAXES \\
    @Override
    public List<Tax> getAllTaxes() {
        List<Tax> listTaxes = onlyTax.getAllTaxes();
        return listTaxes;
    }

    @Override
    public Tax getTaxByState(String state) {
        return onlyTax.getTaxByState(state);
    }
}