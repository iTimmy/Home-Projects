/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooringmastery.dao;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import com.sg.flooringmastery.dao.*;
import com.sg.flooringmastery.dto.Product;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author Music Account
 */
public class FlooringMasteryProductDaoImplTest {
    FlooringMasteryProductDao productDaoTest = new FlooringMasteryProductDaoImpl();
    
    public FlooringMasteryProductDaoImplTest() {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
        productDaoTest = ctx.getBean("productDao", FlooringMasteryProductDao.class);
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
    
    @Test
    public void testGetAllProducts() {
        List<Product> listProducts = productDaoTest.getAllProducts();
        Product product = new Product();
        listProducts.add(product);
        assertEquals(listProducts.size(), 5);
    }
    
    @Test
    public void testGetProductByName() {
        List<Product> listTaxes = new ArrayList<>();
        Product productOne = new Product();
        productOne.setProductType("Vinyl");
        listTaxes.add(productOne);
        
        Product productDaoOne = productDaoTest.getProductByName(productOne.getProductType());
        
        assertEquals(productOne.getProductType(), productOne.getProductType());
    }
}
